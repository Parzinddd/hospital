// pages/baseInfo/baseInfo.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        array: ['身份证', '港澳居民往来大陆通行证', '台湾居民来往大陆通行证','中国护照','境外护照','其他'],
        objectArray: [
          {
            id: 0,
            name: '身份证'
          },
          {
            id: 1,
            name: '港澳居民往来大陆通行证'
          },
          {
            id: 2,
            name: '台湾居民来往大陆通行证'
          },
          {
            id: 3,
            name: '中国护照'
          },
          {
            id: 4,
            name: '境外护照'
          },
          {
            id: 5,
            name: '其他'
          }
        ],
        index: 0,
        date:'2021-01-01',
        sex: ['男','女'],
        objectSex:[
          {
            id:0,
            name:'男'
          },
          {
            id:1,
            name:'女'
          }
        ],
        sexIndex:0,
    },
    
    bindDateChange: function(e) {
      console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        date: e.detail.value
      })
    },
    
    bindPickerChange: function(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
          index: e.detail.value
        })
      },
      bindPickerChange1: function(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
          sexIndex: e.detail.value
        })
      },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})